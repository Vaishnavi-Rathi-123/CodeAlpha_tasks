# Login & Registration System in C++

## Description
This project simulates a basic **Login and Registration System** using C++.  
It allows users to create accounts, log in with their credentials, and ensures secure handling of usernames and passwords.  
The system also validates inputs to prevent duplicate usernames and incorrect logins.

## Features
- User registration with unique username check.
- Secure login with username and password verification.
- Handles errors such as existing usernames, incorrect credentials, or empty inputs.
- Uses **file handling** to store user credentials persistently.
- Simple, console-based interface for ease of use.

## How to Run
1. Open `LoginSystem.cpp` in any C++ IDE (like Code::Blocks, Visual Studio, or online IDE).  
2. Compile the program.  
3. Run the executable.  
4. Follow the on-screen menu to **register a new user** or **log in** with existing credentials.

## Sample Output
=== Login & Registration System ===

1.Register
2.Login
3.Exit
Enter choice: 1

Enter a username: cosmo
Enter a password: 123pass
Registration successful!

=== Login & Registration System ===

1.Register
2.Login
3.Exit
Enter choice: 2

Enter username: cosmo
Enter password: 123pass
Login successful! Welcome cosmo


## Author
**Vaishnavi Rathi**  
## AIML Student | C++ Developer Intern at CodeAlpha
