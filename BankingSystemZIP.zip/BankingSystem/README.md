# Banking System in C++

## Description
This project simulates a basic banking system using C++.  
It allows multiple customers to:
- Deposit money
- Withdraw money
- Transfer money between accounts
- View account information
- Track transaction history

## Features
- Modular code using **OOP concepts**: `Customer`, `Account`, and `Transaction` classes.
- Dynamic storage using **vectors** for customers and transaction history.
- Input validation to prevent invalid operations.
- Transaction history for transparency.

## How to Run
1. Open `BankingSystem.cpp` in a C++ IDE (like Code::Blocks, Visual Studio, or an online compiler).  
2. Compile the file.  
3. Run the executable and follow the menu prompts.

## Sample Output
=== Banking System ===

Deposit

Withdraw

Transfer

Show Info

Show Transactions

Exit
Enter choice: 1
Enter Customer ID: 101
Enter deposit amount: 2000
Deposit successful. Balance: 7000



## Author
**Vaishnavi Rathi**  
## AIML Student | C++ Developer Intern at CodeAlpha
