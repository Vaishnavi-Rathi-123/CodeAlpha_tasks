#include <iostream>
#include <fstream>
#include <string>
using namespace std;

// Function to check if a file exists
bool fileExists(const string& filename) 
{
    ifstream file(filename);
    return file.is_open();
}

// Function to register a new user
void registerUser() 
{
    string username, password;
    cout << "Enter a username: ";
    cin >> username;

    // Check if user already exists
    if (fileExists(username + ".txt")) 
    {
        cout << "Error: Username already exists. Try a different one.\n";
        return;
    }

    cout << "Enter a password: ";
    cin >> password;

    // Simple password validation
    if (password.length() < 6)
    {
        cout << "Error: Password must be at least 6 characters long.\n";
        return;
    }

    // Store credentials in a file
    ofstream userFile(username + ".txt");
    if (userFile.is_open())
    {
        userFile << username << endl;
        userFile << password << endl;
        userFile.close();
        cout << "Registration successful!\n";
    }
    else 
    {
        cout << "Error: Unable to create user file.\n";
    }
}

// Function to login a user
void loginUser()
{
    string username, password, storedUsername, storedPassword;
    cout << "Enter your username: ";
    cin >> username;
    cout << "Enter your password: ";
    cin >> password;

    ifstream userFile(username + ".txt");
    if (!userFile.is_open()) 
    {
        cout << "Error: User not found. Please register first.\n";
        return;
    }

    getline(userFile, storedUsername);
    getline(userFile, storedPassword);
    userFile.close();

    if (username == storedUsername && password == storedPassword)
    {
        cout << "Login successful! Welcome, " << username << ".\n";
    } 
    else
    {
        cout << "Error: Incorrect username or password.\n";
    }
}

int main()
{
    int choice;

    while (true) 
    {
        cout << "\n===== LOGIN & REGISTRATION SYSTEM =====\n";
        cout << "1. Register\n2. Login\n3. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice)
        {
            case 1:
                registerUser();
                break;
            case 2:
                loginUser();
                break;
            case 3:
                cout << "Exiting program. Goodbye!\n";
                return 0;
            default:
                cout << "Invalid choice. Try again.\n";
        }
    }

    return 0;
}
