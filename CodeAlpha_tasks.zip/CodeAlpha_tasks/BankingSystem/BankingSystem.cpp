#include <iostream>
#include <vector>
#include <string>
using namespace std;

class Transaction 
{
public:
    string type;
    double amount;
    Transaction(string t, double a) : type(t), amount(a) {}
};

class Account 
{
public:
    int accountNumber;
    double balance;
    vector<Transaction> history;

    Account(int accNo, double initialBalance = 0)
    {
        accountNumber = accNo;
        balance = initialBalance;
    }

    void deposit(double amount) 
    {
        if (amount <= 0) 
        {
            cout << "Invalid amount!\n"; return;
        }
        
        balance += amount;
        history.push_back(Transaction("Deposit", amount));
        cout << "Deposit successful. Balance: " << balance << endl;
    }

    void withdraw(double amount) 
    {
        if (amount <= 0 || amount > balance) 
        { 
            cout << "Invalid/Insufficient balance!\n"; return; 
        }
        balance -= amount;
        history.push_back(Transaction("Withdrawal", amount));
        cout << "Withdrawal successful. Balance: " << balance << endl;
    }

    bool transfer(Account &toAccount, double amount) 
    {
        if (amount <= 0 || amount > balance)
        {
            cout << "Invalid transfer amount!\n";
            return false;
        }
        balance -= amount;
        toAccount.balance += amount;

        history.push_back(Transaction("Transfer to " + to_string(toAccount.accountNumber), amount));
        toAccount.history.push_back(Transaction("Received from " + to_string(accountNumber), amount));

        cout << "Transfer successful. Your new balance: " << balance << endl;
        return true;
    }

    void showTransactions()
    {
        cout << "\nTransaction History for Account " << accountNumber << ":\n";
        for (auto &t : history)
            cout << t.type << " : " << t.amount << endl;
    }
};

class Customer 
{
public:
    string name;
    int customerID;
    Account account;

    Customer(string n, int id, double balance = 0) : name(n), customerID(id), account(id, balance) {}

    void showInfo()
    {
        cout << "\nCustomer: " << name << "\nID: " << customerID
             << "\nAccount Number: " << account.accountNumber
             << "\nBalance: " << account.balance << endl;
    }
};

int main()
{
    vector<Customer> customers = 
    {
        Customer("Alice", 101, 5000),
        Customer("Bob", 102, 3000)
    };

    int choice;
    while (true) 
    {
        cout << "\n=== Banking System ===\n";
        cout << "1. Deposit\n2. Withdraw\n3. Transfer\n4. Show Info\n5. Show Transactions\n6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        if (choice == 6) break;

        int id;
        cout << "Enter Customer ID: ";
        cin >> id;

        Customer* cust = nullptr;
        for (auto &c : customers)
        {
            if (c.customerID == id) 
            { 
                cust = &c; break;
            }
        }
        if (!cust)
        { 
            cout << "Customer not found!\n"; continue; 
            
        }

        if (choice == 1) 
        {
            double amt; cout << "Enter deposit amount: "; cin >> amt;
            cust->account.deposit(amt);
        }
        else if (choice == 2) 
        {
            double amt; cout << "Enter withdrawal amount: "; cin >> amt;
            cust->account.withdraw(amt);
        }
        else if (choice == 3) 
        {
            double amt; int toID; 
            cout << "Enter recipient Customer ID: "; cin >> toID;
            Customer* toCust = nullptr;
            for (auto &c : customers)
            {
                if (c.customerID == toID) 
                {
                    toCust = &c; break; 
                }
            }
            if (!toCust)
            { 
                cout << "Recipient not found!\n"; continue; 
            }
            cout << "Enter amount to transfer: "; cin >> amt;
            cust->account.transfer(toCust->account, amt);
        }
        else if (choice == 4) 
        {
            cust->showInfo();
        }
        else if (choice == 5)
        {
            cust->account.showTransactions();
        }
        else
        {
            cout << "Invalid choice!\n";
        }
    }

    cout << "Thank you for using the Banking System.\n";
    return 0;
}


