# CGPA Calculator in C++

## Description
This C++ program calculates the **CGPA** of a student based on marks obtained in multiple subjects.  
It allows the user to input marks, calculates grade points, and computes the cumulative grade point average.

## Features
- Accepts marks for multiple courses.
- Calculates grades and grade points automatically.
- Computes CGPA based on total grade points.
- Simple and easy-to-use console interface.

## How to Run
1. Open `CGPACalculator.cpp` in a C++ IDE.  
2. Compile the file.  
3. Run the program and follow the on-screen instructions.

## Sample Output
Enter marks for 5 subjects:
95 88 76 64 58
CGPA: 8.6
Grades: A+, A, B+, B, C



## Author
**Vaishnavi Rathi**  
## AIML Student | C++ Developer Intern at CodeAlpha
