#include <iostream>
#include <string>
using namespace std;

// Function to convert letter grade to numeric value
double letterToNumeric(string grade)
{
    if (grade == "A+") return 10.0;
    else if (grade == "A") return 9.0;
    else if (grade == "B+") return 8.0;
    else if (grade == "B") return 7.0;
    else if (grade == "C") return 6.0;
    else if (grade == "D") return 5.0;
    else if (grade == "F") return 0.0;
    else
    {
        cout << " Invalid grade entered! Assuming 0.0" << endl;
        return 0.0; // default if invalid
    }
}

int main()
{
    int numCourses;
    cout << "\n\n\t==================== CGPA CALCULATOR ====================\n\n";
    cout << " Enter number of courses this semester: ";
    cin >> numCourses;
    cin.ignore(1000, '\n'); // flush buffer

    string courseName, gradeLetter;
    double gradeValue, creditHours;
    double totalCredits = 0, totalGradePoints = 0;

    string courses[numCourses];
    string grades[numCourses];
    double credits[numCourses];

    cout << "\n\n ------------ Enter Course Details ------------\n\n";
    cout << " (Use letter grades: A+, A, B+, B, C, D, F)\n\n";

    for (int i = 0; i < numCourses; i++) 
    {
        cout << " Course " << i + 1 << " name: ";
        getline(cin, courseName);

        cout << " Grade for " << courseName << " (A+, A, B+, B, C, D, F): ";
        cin >> gradeLetter;

        cout << " Credit hours for " << courseName << ": ";
        cin >> creditHours;

        cin.ignore(1000, '\n'); 

        gradeValue = letterToNumeric(gradeLetter);

        courses[i] = courseName;
        grades[i] = gradeLetter;
        credits[i] = creditHours;

        totalCredits += creditHours;
        totalGradePoints += (gradeValue * creditHours);

        cout << "\n------------------------------------------------\n\n";
    }

    double gpa = totalGradePoints / totalCredits;

    cout << "\n\n\t================== SEMESTER TRANSCRIPT ==================\n\n";
    
    for (int i = 0; i < numCourses; i++) 
    {
        double numeric = letterToNumeric(grades[i]);
        cout << " Course: " << courses[i]
             << " | Grade: " << grades[i]
             << " | Numeric: " << numeric
             << " | Credits: " << credits[i]
             << " | Grade Points: " << (numeric * credits[i]) << endl;
    }

    cout << "\n----------------------------------------------------------\n";
    cout << " Total Credits       : " << totalCredits << endl;
    cout << " Total Grade Points  : " << totalGradePoints << endl;
    cout << " Semester GPA        : " << gpa << endl;
    cout << " Overall CGPA        : " << gpa << endl;

    cout << "\n ===========================================================================\n\n";
    cout << "\t ********** Congratulations on completing your semester! **********\n\n";

    return 0;
}
